subject=input("Enter your favourite subject:")
if subject=="maths":
    print("You are mpc student")
elif subject=="physics":
    print("You are mpc student")
elif subject=="chemistry":
    print("You are mpc student")
else:
    print(You are not a mpc student")